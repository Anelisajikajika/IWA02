
console.warn('Security scan starting');

/* It is important to let user know when they can close the page  */

console.info('Please wait for scan to complete before closing the browser.');