/* This is the firstname of the user */

const user = 'John'
console.log(user)


/* This is the lastname of the user */ 
const surname = 'Smith'

console.log(surname)